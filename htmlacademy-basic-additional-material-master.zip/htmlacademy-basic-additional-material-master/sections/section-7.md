[Вернуться к списку разделов.](../README.md)

## **Введение в JavaScript**
Введение в JavaScript, написание простейших скриптов.

#### Статьи
----------
[«Try jQuery»](https://www.codeschool.com/courses/try-jquery) — интерактивный курс по jQuery от Code School.

[«You might not need jQuery»](http://youmightnotneedjquery.com/) — тебе не нужно использовать jquery

#### Сдача проекта
----------
[Критерии сдачи финального проекта](../articles/критерии-сдачи-финального-проекта/article.md)

#### Скринкасты
----------
[Сергей Попов. «Вставляем интерактивную карту»](https://youtu.be/FXT0zpss2x4)

[Сергей Попов. «Проверка проекта перед отправкой на финальную оценку»](https://youtu.be/1Fs-L46dHpM)

#### Другие материалы
----------
[Cниппеты для Sublime Text для быстрого написания js.](https://packagecontrol.io/packages/JavaScript%20%26%20NodeJS%20Snippets)

[Owl carousel](http://www.owlcarousel.owlgraphic.com/) — мощный слайдер с подробной документацией и примерами.
