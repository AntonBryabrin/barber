[Вернуться к списку разделов.](../README.md)

## Методологии
Методологии **БЭМ** и **SMACSS**. Приемы создания надежной верстки.

#### Статьи
------
[Верстка для самых маленьких. Верстаем страницу по БЭМу](https://habrahabr.ru/post/203440/)

[Типичные ошибки, которые совершают студенты начиная использовать БЭМ](https://github.com/tsergeytovarov/htmlacademy-basic-additional-material/blob/master/articles/ошибки-бэм/article.md)

#### Скринкасты
------
[Скринкаст: небольшое введение в БЭМ и разметка страницы по БЭМ](https://www.youtube.com/watch?v=txUZrAQnSLg&list=PLQPQDQeOswiX4D7VpMt_C9Cz2Bzdi4Fn3&index=2)

#### Видео
------
[БЭМ — норм, Вадим Макеев](https://youtu.be/RM55tkWfHDc)
