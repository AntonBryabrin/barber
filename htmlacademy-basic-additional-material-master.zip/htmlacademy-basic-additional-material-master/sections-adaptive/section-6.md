[Вернуться к списку разделов.](../README.md)

## Адаптивность: графика
Адаптивные графика и медиаконтент, оптимизация, ретина, работа с SVG.

#### Статьи
----------
[Использование SVG](http://frontender.info/using-svg/)

[Переосмысление отзывчивого SVG](http://frontender.info/rethinking-responsive-svg/)

[SVG в вебе. Практическое руководство](https://svgontheweb.com/ru/)
