[Вернуться к списку разделов.](../README.md)

## Автоматизация
Машины должны страдать!

#### Статьи
----------
[Gulp или Grunt, да всё равно](http://frontender.info/gulp-grunt-whatever/)

[Grunt для тех, кто считает штуки вроде него странными и сложными](http://frontender.info/grunt-is-not-weird-and-hard/)

[Gulp — как глоток свежего воздуха после Grunt](http://frontender.info/no-need-to-grunt-take-a-gulp-of-fresh-air/)

#### Скринкасты
----------
[Детально про Gulp и рецепты его использования](https://learn.javascript.ru/screencast/gulp)

#### Другие материалы
----------
