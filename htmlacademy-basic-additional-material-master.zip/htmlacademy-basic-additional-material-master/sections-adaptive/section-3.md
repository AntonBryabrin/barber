[Вернуться к списку разделов.](../README.md)

## Препроцессоры CSS
Взглянем на LESS и SASS и разберемся как с ними работать.

#### Статьи
-----
[Sass: Структура каталога, которая поможет вам поддерживать код.](http://vanseodesign.com/css/sass-directory-structures/)

[Чуть больше Sass для (БЭ)Модификаторов](http://frontender.info/bem-sass-modifiers/)

#### Скринкасты
-----
[Обзор языка препроцессора SASS](https://www.youtube.com/watch?v=9vuvqH1gvxs&index=1&list=PLQPQDQeOswiX4D7VpMt_C9Cz2Bzdi4Fn3)
