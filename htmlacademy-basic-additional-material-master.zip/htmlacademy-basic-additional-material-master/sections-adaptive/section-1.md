[Вернуться к списку разделов.](../README.md)

## Вводный
Знакомимся с Гитом и рабочим процессом на интенсиве.

#### Статьи
----------
[Как использовать консоль в Windows](http://nicothin.ru/page/console-windows)

[Как комфортно работать с GitHub в консоли Windows](http://nicothin.ru/page/kak-komfortno-rabotat-s-github-v-konsoli-windows)

[Атомарные коммиты](https://github.com/tsergeytovarov/htmlacademy-basic-additional-material/blob/master/articles/атомарные-коммиты/article.md)

[Github Workflow](https://www.atlassian.com/git/tutorials/comparing-workflows/forking-workflow)

[Установка терминала на Windows](https://htmlacademy.ru/blog/83-installing-the-console-on-windows)

[Регистрация на Гитхабе, работа через консоль](https://htmlacademy.ru/blog/84-register-on-github-work-with-console)

[Регистрация на Гитхабе, работа через GitHub Desktop](https://htmlacademy.ru/blog/85-register-on-github-work-with-github-desktop)

[Полезные команды для работы с Git](https://htmlacademy.ru/blog/86-useful-commands-for-working-with-git)

[Установка Node.js](https://htmlacademy.ru/blog/87-installing-nodejs)

[Полезные команды для работы с Node.js](https://htmlacademy.ru/blog/88-useful-commands-for-working-with-nodejs)

[Глоссарий терминов для Git и GitHub](https://htmlacademy.ru/blog/81-git-and-github-glossary)

#### Скринкасты
----------


#### Полезные материалы
----------
