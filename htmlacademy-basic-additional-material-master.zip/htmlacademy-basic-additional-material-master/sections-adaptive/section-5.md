[Вернуться к списку разделов.](../README.md)

## Флексбокс
Основные понятия. Применение на практике.

#### Статьи
----------
[Полное руководство по Flexbox](http://frontender.info/a-guide-to-flexbox/)

[Как попасть в макет и не сойти с ума](https://isqua.ru/blog/2016/05/30/kak-popast-v-makiet-i-nie-soiti-s-uma/)

[Краш-тест вёрстки](https://isqua.ru/blog/2016/06/19/crash-test-viorstki/)

#### Другие материалы
----------
[Тренажер Flexbox](http://flexboxfroggy.com/#ru)

[Изучаем flexbox, играя в Tower Defense](http://www.flexboxdefense.com/)

[Песочница с демонстрацией основных свойств Flexbox](http://codepen.io/enxaneta/full/adLPwv/)

#### Курсы
----------

[HTML Academy. Курс «Флексбокс, часть 1» (доступен по подписке)](https://htmlacademy.ru/courses/96)

[HTML Academy. Курс «Флексбокс, часть 2» (доступен по подписке)](https://htmlacademy.ru/courses/113)
