[Вернуться к списку разделов.](../README.md)

## Инструменты ускорения вёрстки
Ускоряемся. Обзор фреймворков и библиотек компонентов.

#### Статьи
----------
[Gulp или Grunt, да всё равно](http://frontender.info/gulp-grunt-whatever/)

[Grunt для тех, кто считает штуки вроде него странными и сложными](http://frontender.info/grunt-is-not-weird-and-hard/)

[Gulp — как глоток свежего воздуха после Grunt](http://frontender.info/no-need-to-grunt-take-a-gulp-of-fresh-air/)

#### Скринкасты
----------
[Детально про Gulp и рецепты его использования](https://learn.javascript.ru/screencast/gulp)

#### Другие материалы
----------
[Что должен знать HTML-верстальщик?](http://krekotun.ru/ui-developer-skills)
